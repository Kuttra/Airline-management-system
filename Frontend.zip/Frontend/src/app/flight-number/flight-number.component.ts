import { Component } from '@angular/core';

@Component({
  selector: 'app-flight-number',
  templateUrl: './flight-number.component.html',
  styleUrl: './flight-number.component.css'
})
export class FlightNumberComponent {

}
